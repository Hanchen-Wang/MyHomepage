import random
import math
from utils import *
from copy import deepcopy


def create_training(training_option, baseline_dict):
    pattern_list = list(baseline_dict.keys())
    if training_option == 0:
        train_file_list = []
        for p in pattern_list:
            if '_4_' in p:   # depending on the graphs here, we need to change the file name.
                train_file_list.append(p)
        train_num = math.floor(len(train_file_list) * 0.5)
        train_pattern = random.sample(train_file_list, train_num)
        test_pattern = deepcopy(train_file_list)
        for p in train_pattern:
            test_pattern.remove(p)
    elif training_option == 1:
        train_file_list = []
        for p in pattern_list:
            if '_8_' in p and 'dense' in p:  # depending on the graphs here, we need to change the file name.
                train_file_list.append(p)
        train_num = math.floor(len(train_file_list) * 0.3)
        train_pattern = random.sample(train_file_list, train_num)
        test_pattern = deepcopy(train_file_list)
        for p in train_pattern:
            test_pattern.remove(p)
        # train_file_list = []
        # for p in pattern_list:
        #     if '_4_' in p:
        #         train_file_list.append(p)
        # train_num = math.floor(len(train_file_list) * 0.5)
        # train_pattern = random.sample(train_file_list, train_num)
        # test_pattern = deepcopy(train_file_list)
        # for p in train_pattern:
        #     test_pattern.remove(p)
        # for p in pattern_list:
        #     if '_4_' in p:
        #         train_pattern.append(p)
    elif training_option == 2:
        train_file_list = []
        for p in pattern_list:
            if '_16_' in p:  # depending on the graphs here, we need to change the file name.
                train_file_list.append(p)
        train_num = math.floor(len(train_file_list) * 0.5)
        train_pattern = random.sample(train_file_list, train_num)
        test_pattern = deepcopy(train_file_list)
        for p in train_pattern:
            test_pattern.remove(p)
    elif training_option == 32:
        train_file_list = []
        for p in pattern_list:
            if '_32_' in p:  # depending on the graphs here, we need to change the file name.
                train_file_list.append(p)
        train_num = math.floor(len(train_file_list) * 0.5)
        train_pattern = random.sample(train_file_list, train_num)
        test_pattern = deepcopy(train_file_list)
        for p in train_pattern:
            test_pattern.remove(p)
    elif training_option == 24:
        train_file_list = []
        for p in pattern_list:
            if 'dense_24_' in p:  # depending on the graphs here, we need to change the file name.
                train_file_list.append(p)
        train_num = math.floor(len(train_file_list) * 0.5)
        train_pattern = random.sample(train_file_list, train_num)
        test_pattern = deepcopy(train_file_list)
        for p in train_pattern:
            test_pattern.remove(p)
    else:
        raise NotImplementedError

    train_dict = dict()
    test_dict = dict()
    for p in train_pattern:
        p_new = p.replace('query_graph', 'grf_query_graph').replace('.graph', '.grf')
        train_dict[p] = load_p_data(p_new)
    for p in test_pattern:
        p_new = p.replace('query_graph', 'grf_query_graph').replace('.graph', '.grf')
        test_dict[p] = load_p_data(p_new)

    return train_pattern, test_pattern, train_dict, test_dict


