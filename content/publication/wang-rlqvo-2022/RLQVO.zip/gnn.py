import torch
import torch.nn as nn
import torch.functional as F
import torch_geometric
import torch_geometric.nn as geo_nn


class GCN(torch.nn.Module):
    def __init__(self, args, p_net=False):
        super(GCN, self).__init__()
        self.args = args
        # define the input features.
        if p_net == True:
            self.gcn_layer1 = geo_nn.GCNConv(6, self.args.hidden_dim)
        else:
            self.gcn_layer1 = geo_nn.GCNConv(self.args.in_feat, self.args.hidden_dim)
        self.gcn_layer2 = geo_nn.GCNConv(self.args.hidden_dim, self.args.out_dim)
        self.mlp_1 = nn.Linear(self.args.hidden_dim, self.args.hidden_dim)
        self.mlp_2 = nn.Linear(self.args.out_dim, self.args.out_dim)
        self.act_func1 = nn.ReLU()
        self.act_func2 = nn.ReLU()

    def forward(self, x, edge_index, edge_weight=None):
        # two layered GCN network
        x = self.gcn_layer1(x, edge_index, edge_weight)
        # x = self.act_func1(self.mlp_1(x))
        x = self.act_func1(x)
        x = self.gcn_layer2(x, edge_index, edge_weight)
        # x = self.act_func2(self.mlp_2(x))
        x = self.act_func2(x)

        return x
