import torch
import os
import numpy as np
import signal
import time
import subprocess
from copy import deepcopy
from tqdm import tqdm
from functools import wraps


def get_emb(u, v , ul, vl, el):
    # return the node feature and edge feature.
    pass


def get_enc_len(x, base=10):
    # return math.floor(math.log(x, base)+1.0)
    l = 0
    while x:
        l += 1
        x = x // base
    return l


def int2onehot(x, len_x, fixed_length, base=10):
    # get the one hot representation for each node.
    if isinstance(x, (int, list)):
        x = np.array(x)
    x_shape = x.shape
    x = x.reshape(-1)
    max_value = x.max()
    one_hot = np.zeros((x.shape[0], fixed_length), dtype=np.float32)
    if max_value >= 2**base:
        for i in range(x.shape[0]):
            binarized = bin(x[i]).replace('0b','')
            for j in reversed(range(len(binarized))):
                one_hot[i][j] = binarized[j]
    else:
        for i in range(x.shape[0]):
            small_vec = np.zeros((base), dtype=np.float32)
            binarized = bin(x[i]).replace('0b','')
            for j in reversed(range(len(binarized))):
                small_vec[j] = binarized[j]
            idx = one_hot.shape[1] - base
            while idx >=0:
                one_hot[i][idx:idx+base] = small_vec
                idx -= base
    # # force the length of the one_hot vector
    # # one_hot = np.zeros((len_x * base, x.shape[0]), dtype=np.float32)
    #
    # # x = x % (base ** len_x)
    # x = x%fixed_length
    # new_x = x
    # idx = one_hot.shape[0] - base
    # while idx >= 0:
    #     x = new_x
    #     while np.any(x):
    #         x, y = x // base, x % base
    #         cond = y.reshape(1, -1) == np.arange(0, base, dtype=y.dtype).reshape(base, 1)
    #         one_hot[idx:idx + base] = np.where(cond, 1.0, 0.0)
    #         idx -= base
    # # while idx >= 0:
    # #     # one_hot[idx] = 1.0
    # #     y = x % base
    # #     cond = y.reshape(1, -1) == np.arange(0, base, dtype=y.dtype).reshape(base, 1)
    # #     one_hot[idx:idx + base] = np.where(cond, 1.0, 0.0)
    # #     idx -= base
    # one_hot = one_hot.transpose(1, 0).reshape(*x_shape, fixed_length)
    one_hot.reshape(*x_shape, fixed_length)
    # print(one_hot.shape)
    return one_hot


def load_g_graph(g_file):
    nid = list()
    nlabel = list()
    nindeg = list()
    elabel = list()
    e_u = list()
    e_v = list()
    with open(g_file) as f2:
        num_nodes = int(f2.readline().rstrip())
        for i in range(num_nodes):
            node_info = f2.readline()
            node_id, node_label = node_info.rstrip().split()
            nid.append(int(node_id))
            nlabel.append(int(node_label))
        while True:
            line = f2.readline()
            # read until the end of the file.
            if not line:
                break
            temp_indeg = int(line.strip())
            nindeg.append(temp_indeg)
            if temp_indeg == 0:
                continue
            for i in range(temp_indeg):
                edge_info = f2.readline().rstrip().split()
                if len(edge_info) == 2:
                    edge_label = 1
                else:
                    edge_label = int(edge_info[-1])
                e_u.append(int(edge_info[0]))
                e_v.append(int(edge_info[1]))
                elabel.append(edge_label)
    g_nid = deepcopy(nid)
    g_nlabel = deepcopy(nlabel)
    g_indeg = deepcopy(nindeg)
    g_edges = [deepcopy(e_u), deepcopy(e_v)]
    g_elabel = deepcopy(elabel)
    graph_info = [
        g_nid,
        g_nlabel,
        g_indeg,
        g_edges,
        g_elabel
    ]
    return graph_info


def load_p_data(p_file):
    nid = list()
    nlabel = list()
    nindeg = list()
    elabel = list()
    e_u = list()
    e_v = list()

    with open(p_file) as f1:
        num_nodes = int(f1.readline().rstrip())
        for i in range(num_nodes):
            node_info = f1.readline()
            node_id, node_label = node_info.rstrip().split()
            # print(node_id)
            # print(node_label)
            nid.append(int(node_id))
            nlabel.append(int(node_label))
        while True:
            line = f1.readline()
            # read until the end of the file.
            if not line:
                break
            temp_indeg = int(line.strip())
            nindeg.append(temp_indeg)
            if temp_indeg == 0:
                continue
            for i in range(temp_indeg):
                edge_info = f1.readline().rstrip().split()
                if len(edge_info) == 2:
                    edge_label = 1
                else:
                    edge_label = int(edge_info[-1])
                e_u.append(int(edge_info[0]))
                e_v.append(int(edge_info[1]))
                elabel.append(edge_label)
    p_nid = deepcopy(nid)
    p_nlabel = deepcopy(nlabel)
    p_indeg = deepcopy(nindeg)
    p_edges = [deepcopy(e_u), deepcopy(e_v)]
    p_elabel = deepcopy(elabel)
    pattern_info = [
        p_nid,
        p_nlabel,
        p_indeg,
        p_edges,
        p_elabel
    ]
    return pattern_info


def load_data(p_file_list, g_file):
    pattern_info = list()
    for p_file in tqdm(p_file_list):
        pattern_info.append(load_p_data(p_file))

    graph_info = load_g_graph(g_file)

    return pattern_info, graph_info


def preprocess_query(pattern_info, start_index=None):
    num_nodes = len(pattern_info[0])  # number of nodes in the pattern graph.
    if start_index is None:
        p_indeg = pattern_info[2]
        max_value = max(p_indeg)  # the first node is selected by the maximum in degree.
        node_index = p_indeg.index(max_value)
    else:
        node_index = start_index
    start_id = pattern_info[0][node_index]
    start_label = pattern_info[1][node_index]
    # the feature information of the first node.
    pattern_feature = torch.cat([torch.from_numpy(int2onehot(start_id, num_nodes, 64, 8)), torch.from_numpy(int2onehot(start_label, num_nodes, 64, 8))], dim=1)
    # print(pattern_feature.size())
    # this new edgelist should be changed, the index could be other than 0.
    # need new pattern feature
    new_edgelist = torch.tensor([[0], [0]])   # we add a self-loop here for easy computation in the GCN.

    return start_id, start_label, pattern_feature, new_edgelist


def get_num_label(graph_info, data_info):
    # get number of nodes with the same label in the data graph.
    label_num_dict = dict()
    labels = data_info[1]
    for label in labels:
        if label not in label_num_dict:
            label_num_dict[label] = 1
        else:
            label_num_dict[label]+=1
    label_num = list()
    for label in graph_info[1]:
        label_num.append(label_num_dict[label])
    return label_num


def get_less_degree(graph_info, data_info):
    # get number of nodes with larger degree in the data graph.
    degree_info = data_info[2]
    degree_dict = dict()
    for d in degree_info:
        if d not in degree_dict:
            degree_dict[d] = 1
        else:
            degree_dict[d] += 1
    degree_keys = list(degree_dict.keys())
    less_degree = list()
    for d in graph_info[2]:
        count = 0
        for dk in degree_keys:
            if dk>=d:
                count+=degree_dict[dk]
        less_degree.append(count)
    return less_degree


def preprocess_data_graph(graph_info):
    num_nodes = len(graph_info[0])  # number of nodes in the data graph.
    graph_feature = torch.cat([torch.from_numpy(int2onehot(graph_info[0], num_nodes, 64, 8)), torch.from_numpy(int2onehot(graph_info[1], num_nodes, 64, 8))], dim=1)
    # new feature input
    # num_label = get_num_label(graph_info)
    # less_degree = get_less_degree(graph_info)
    # graph_feature = torch.cat([torch.tensor(graph_info[1]), torch.tensor(graph_info[0]), torch.tensor(graph_info[2]), torch.tensor(num_label)], dim=1)
    graph_elist = torch.tensor(graph_info[3])
    graph_indeg = torch.tensor(graph_info[2])
    graph_elabel = torch.tensor(graph_info[4])

    return graph_feature, graph_elist, graph_indeg, graph_elabel


def preprocess_query_graph(query_info, data_info):
    num_nodes = len(query_info[0])  # number of nodes in the data graph.
    # graph_feature = torch.cat([torch.from_numpy(int2onehot(graph_info[0], num_nodes, 64, 8)), torch.from_numpy(int2onehot(graph_info[1], num_nodes, 64, 8))], dim=1)
    # new feature input
    num_label = get_num_label(query_info, data_info)
    less_degree = get_less_degree(query_info, data_info)
    indicator = [0] * num_nodes
    graph_feature = torch.cat([torch.tensor(query_info[1]).unsqueeze(0), torch.tensor(query_info[0]).unsqueeze(0),
                               torch.tensor(query_info[2]).unsqueeze(0), torch.tensor(num_label).unsqueeze(0),
                               torch.tensor(less_degree).unsqueeze(0), torch.tensor(indicator).unsqueeze(0)], dim=0)
    graph_feature = torch.transpose(graph_feature, 0, 1)   # size:(num_nodes, feature_dim)

    graph_elist = torch.tensor(query_info[3])
    graph_indeg = torch.tensor(query_info[2])
    graph_elabel = torch.tensor(query_info[4])

    return graph_feature, graph_elist, graph_indeg, graph_elabel


def preprocess_query_new(pattern_info, data_info, start_index=None):
    query_info = pattern_info
    num_nodes = len(query_info[0])  # number of nodes in the data graph.
    # graph_feature = torch.cat([torch.from_numpy(int2onehot(graph_info[0], num_nodes, 64, 8)), torch.from_numpy(int2onehot(graph_info[1], num_nodes, 64, 8))], dim=1)
    # new feature input
    if start_index is None:
        p_indeg = pattern_info[2]
        max_value = max(p_indeg)  # the first node is selected by the maximum in degree.
        node_index = p_indeg.index(max_value)
    else:
        node_index = start_index
    num_label = get_num_label(query_info, data_info)
    less_degree = get_less_degree(query_info, data_info)
    indicator = [0] * num_nodes
    indicator[node_index] = 1
    graph_feature = torch.cat([torch.tensor(query_info[1]).unsqueeze(0), torch.tensor(query_info[0]).unsqueeze(0),
                               torch.tensor(query_info[2]).unsqueeze(0), torch.tensor(num_label).unsqueeze(0),
                               torch.tensor(less_degree).unsqueeze(0), torch.tensor(indicator).unsqueeze(0)], dim=0)
    graph_feature = torch.transpose(graph_feature, 0, 1)  # size:(num_nodes, feature_dim)

    # pattern_feature = graph_feature[node_index]
    pattern_feature = graph_feature
    # pattern_feature = pattern_feature.unsqueeze(0)
    pattern_feature = pattern_feature.type(torch.FloatTensor)
    start_id = pattern_info[0][node_index]
    start_label = pattern_info[1][node_index]
    new_edgelist = torch.tensor([[0], [0]])

    return start_id, start_label, pattern_feature, new_edgelist


def compute_new_feat(old_feat, old_elist, order, p_info):
    num_p_nodes = len(p_info[0])
    num_gm_nodes = len(order)  # get the length of current matching graph G_m
    next_node = order[-1]
    n_id = p_info[0][next_node]
    n_label = p_info[1][next_node]
    e_u, e_v = p_info[3]
    new_feat = torch.cat([torch.from_numpy(int2onehot(n_id, num_p_nodes, 64, 8)), torch.from_numpy(int2onehot(n_label, num_p_nodes, 64, 8))], dim=1)
    # new_feat = new_feat.unsqueeze(0)
    p_feat = torch.cat([old_feat, new_feat], dim=0)
    # print(p_feat.size())
    # print(p_feat)
    new_e_u = list()
    new_e_v = list()
    new_e_u.append(num_gm_nodes - 1)
    new_e_v.append(num_gm_nodes - 1)  # add the self-loop.
    for i in range(len(e_u)):
        if int(e_u[i]) == next_node and int(e_v[i]) == next_node:
            continue
        if int(e_u[i]) in order and int(e_v[i])==next_node:
            new_e_u.append(order.index(int(e_u[i])))
            new_e_v.append(order.index(next_node))
        if int(e_u[i])==next_node and int(e_v[i]) in order:
            new_e_u.append(order.index(next_node))
            new_e_v.append(order.index(int(e_v[i])))
    new_elist = torch.cat([torch.tensor(new_e_u).unsqueeze(0), torch.tensor(new_e_v).unsqueeze(0)], dim=0)
    out_elist = torch.cat([old_elist, new_elist], dim=1)

    return p_feat, out_elist


def compute_new_feat_new(old_feat, old_elist, order, p_info, data_info):
    query_info = p_info
    num_p_nodes = len(p_info[0])
    num_gm_nodes = len(order)  # get the length of current matching graph G_m
    next_node = order[-1]
    # n_id = p_info[0][next_node]
    # n_label = p_info[1][next_node]
    # e_u, e_v = p_info[3]
    # num_label = get_num_label(query_info, data_info)
    # less_degree = get_less_degree(query_info, data_info)
    # indicator = [0] * num_p_nodes
    # indicator[next_node] = 1
    # new_feat = torch.cat([torch.tensor(query_info[1]).unsqueeze(0), torch.tensor(query_info[0]).unsqueeze(0),
    #                            torch.tensor(query_info[2]).unsqueeze(0), torch.tensor(num_label).unsqueeze(0),
    #                            torch.tensor(less_degree).unsqueeze(0), torch.tensor(indicator).unsqueeze(0)], dim=0)
    # new_feat = new_feat.type(torch.FloatTensor).transpose(0,1)
    # new_feat = new_feat[next_node]
    # new_feat = new_feat.unsqueeze(0)
    # # new_feat = torch.cat([torch.from_numpy(int2onehot(n_id, num_p_nodes, 64, 8)), torch.from_numpy(int2onehot(n_label, num_p_nodes, 64, 8))], dim=1)
    # # new_feat = new_feat.unsqueeze(0)
    # # print(new_feat.size())
    # # print(old_feat.size())
    # p_feat = torch.cat([old_feat, new_feat], dim=0)
    # print(p_feat.size())
    # print(p_feat)
    # new_e_u = list()
    # new_e_v = list()
    # new_e_u.append(num_gm_nodes - 1)
    # new_e_v.append(num_gm_nodes - 1)  # add the self-loop.
    # for i in range(len(e_u)):
    #     if int(e_u[i]) == next_node and int(e_v[i]) == next_node:
    #         continue
    #     if int(e_u[i]) in order and int(e_v[i])==next_node:
    #         new_e_u.append(order.index(int(e_u[i])))
    #         new_e_v.append(order.index(next_node))
    #     if int(e_u[i])==next_node and int(e_v[i]) in order:
    #         new_e_u.append(order.index(next_node))
    #         new_e_v.append(order.index(int(e_v[i])))
    # new_elist = torch.cat([torch.tensor(new_e_u).unsqueeze(0), torch.tensor(new_e_v).unsqueeze(0)], dim=0)
    # out_elist = torch.cat([old_elist, new_elist], dim=1)
    old_feat[next_node, -1] = 1.0
    p_feat = old_feat
    out_elist = old_elist

    return p_feat, out_elist


def set_timeout(num, callback):
    def wrap(func):
        def handle(signum, frame):  # 收到信号 SIGALRM 后的回调函数，第一个参数是信号的数字，第二个参数是the interrupted stack frame.
            raise RuntimeError

        def to_do(*args, **kwargs):
            try:
                signal.signal(signal.SIGALRM, handle)  # 设置信号和回调函数
                signal.alarm(num)  # 设置 num 秒的闹钟
                # print('start alarm signal.')
                r = func(*args, **kwargs)
                # print('close alarm signal.')
                signal.alarm(0)  # 关闭闹钟
                return r
            except RuntimeError as e:
                print('need callback')
                callback()

        return to_do

    return wrap


def after_timeout():  # 超时后的处理函数
    print("Time out!")
    raise ValueError


@set_timeout(300, after_timeout)
def vf3(p_file, g_file, order=None):
    if order is None:
        command = '/data/hancwang/subgraph_matching/related_works/VF3_edited/vf3lib-master/bin/vf3 '+p_file+' '+ g_file
    else:
        command = '/data/hancwang/subgraph_matching/related_works/VF3_edited/vf3lib-master/bin/vf3 '+p_file+' ' + g_file+ ' '+ order
    # print(command)
    output = os.popen(command)
    return output


def order2str(order_list):
    order_str = ''
    length_list = len(order_list)
    for i in range(length_list):
        order_str += str(order_list[i])
        if i < length_list - 1:
            order_str+=','
    return order_str


def load_baselines(file_name):
    # file loading for the baseline comparison.
    # return the dict whose keys are the path of pattern file and values are the visit num using VF3.
    baseline_dict = dict()
    with open(file_name) as f:
        for line in f:
            sub_file, visit_baseline = line.rstrip().split()
            baseline_dict[sub_file] = float(visit_baseline)

    return baseline_dict


def Subgraph_Matching(p_file, g_file, method, order=None, filter_method=None, engine=None, timeout_sec=500):
    # subgraph matching methods from SIGMOD experiment paper
    # possible methods are QSI, GQL, CECI, DPiso, VF2PP, CFL, RI
    # methods can be 'ours'
    # base_command = '/data/hancwang/subgraph_matching/related_works/SubgraphMatching-master/build/matching/SubgraphMatching.out' + ' -d ' + g_file + ' -q ' + p_file
    base_command = ['/data/hancwang/subgraph_matching/related_works/SubgraphMatching-master/build/matching/SubgraphMatching.out' , '-d', g_file, '-q', p_file]
    if filter_method != None and engine!=None:
        if method == 'ours':
            base_command.extend(['-filter', filter_method,'-engine', engine,'-in_order', order,'-num', 'MAX'])
            command = base_command
            # command = base_command + ' -filter '+filter_method + ' -engine ' + engine +' -in_order '+ order +' -num MAX'
            # print(command)
            # output = os.popen(command)
            output = subprocess.run(command, capture_output=True, timeout=timeout_sec)
            return output
        elif method == 'best':
            base_command.extend(['-filter', 'GQL', '-order', 'RI','-engine', 'QSI', '-num', 'MAX'])
            command = base_command
            output = subprocess.run(command, capture_output=True, timeout=timeout_sec)
            return output
    if order is None:
        if method == 'QSI':
            # command = base_command + ' -filter LDF -order QSI -engine QSI -num MAX'
            base_command.extend(['-filter', 'LDF', '-order','QSI','-engine','QSI', '-num','MAX'])
            command = base_command
        elif method == 'GQL':
            base_command.extend(['-filter', 'GQL', '-order', 'GQL', '-engine', 'GQL', '-num', 'MAX'])
            command = base_command
            # command = base_command + ' -filter GQL -order GQL -engine GQL -num MAX'
        elif method == 'CECI':
            base_command.extend(['-filter', 'CECI', '-order', 'CECI', '-engine', 'CECI', '-num', 'MAX'])
            command = base_command
            # command = base_command + ' -filter CECI -order CECI -engine CECI -num MAX'
        elif method == 'DPiso':
            base_command.extend(['-filter', 'DPiso', '-order', 'DPiso', '-engine', 'DPiso', '-num', 'MAX'])
            command = base_command
            # command = base_command + ' -filter DPiso -order DPiso -engine DPiso -num MAX'
        elif method == 'VF2PP':
            base_command.extend(['-filter', 'LDF', '-order', 'VF2PP', '-engine', 'QSI', '-num', 'MAX'])
            command = base_command
            # command = base_command + ' -filter LDF -order VF2PP -engine QSI -num MAX'
        elif method == 'CFL':
            base_command.extend(['-filter', 'CFL', '-order', 'CFL', '-engine', 'EXPLORE', '-num', 'MAX'])
            command = base_command
            # command = base_command + ' -filter CFL -order CFL -engine EXPLORE -num MAX'
        elif method == 'RI':
            base_command.extend(['-filter', 'LDF', '-order', 'RI', '-engine', 'QSI', '-num', 'MAX'])
            command = base_command
            # command = base_command + ' -filter LDF -order RI -engine QSI -num MAX'
        else:
            raise NotImplementedError
        # output = os.popen(command)
        output = subprocess.run(command, capture_output=True, timeout=timeout_sec)
        return output


def load_first_node(file_name):
    f_n_dict = dict()
    with open(file_name) as f:
        for line in f:
            sub_file, first_node = line.rstrip().split()
            f_n_dict[sub_file] = int(first_node)
    return f_n_dict


def write_result(file_name, res_l):
    with open(file_name, 'w') as f:
        for i in range(len(res_l)):
            for j in range(len(res_l[i])):
                f.write(str(res_l[i][j])+' ')
            f.write('\n')


def write_time(file_name, time_l):
    with open(file_name, 'w') as f:
        for i in range(len(time_l)):
            for j in range(len(time_l[i])):
                f.write(str(time_l[i][j])+' ')
            f.write('\n')