import torch
import torch.nn as nn
import torch.nn.functional as F
import torch_geometric
import torch_geometric.nn as geo_nn
import os
from gnn import GCN


class Agent(nn.Module):
    # the agent that take the state and influence the environment.
    # input: pattern graph (feature: x, edge_list, edge_weight)
    # data graph (feature: x, edge_list, edge_weight)
    # potential node list (n*1)
    # max_hop? the maximum number of hops the search will reach.
    # output: the probability for the next node (n*1).
    # each step, when get the probability, update the query graph for next step's computation.
    # until the max_hop is reached, and the search is stopped and the order of the nodes is output.
    ################# TODO: forget the edge labels.
    def __init__(self, args, out_nodes, origin_p):
        super(Agent, self).__init__()
        self.out_nodes = out_nodes
        self.origin_p = origin_p
        share_net = args.share_net
        if share_net:
            self.p_net = self.g_net = GCN(args)
        else:
            # self.p_net = GCN(args)
            self.p_net = GCN(args, True)
            self.g_net = GCN(args)

        self.mlp_1 = nn.Linear(2 * args.out_dim, out_nodes)

    def forward(self, p_x, p_elist, g_x, g_elist, order, p_eweight=None, g_eweight=None, origin_p=None):
        if origin_p is not None:
            self.origin_p = origin_p
        p_feat = self.p_net(p_x, p_elist, p_eweight)
        g_feat = self.g_net(g_x, g_elist, g_eweight)
        p_feat = torch_geometric.nn.global_mean_pool(p_feat, torch.tensor([0]*p_feat.size(0)))
        g_feat = torch_geometric.nn.global_mean_pool(g_feat, torch.tensor([0]*g_feat.size(0)))
        # need to pool the feature into one dim vector.
        # print('pattern feature is:')
        # print(p_feat)
        # print('graph feature is:')
        # print(g_feat)
        in_feat = torch.cat((p_feat, g_feat), dim=1)
        out_prob = F.softmax(F.relu(self.mlp_1(in_feat)))
        origin_prob = out_prob.clone()
        # print(out_prob)
        # out_prob = F.relu(self.mlp_1(in_feat))
        # print(self.origin_p)
        # print('order is: ')
        # print(order)
        mask = self.build_mask(order)
        # print('mask is :')
        # print(mask)
        if mask is None:
            return None  # reach the end of the search
        # mask, the position for 0 should be 1.
        masked_prob = out_prob.masked_fill(mask, value=torch.tensor(0.0))
        # masked_prob = F.softmax(out_prob.masked_fill(mask, value=torch.tensor(0.0)))
        # print(masked_prob)
        # we may need to mask out the existing nodes

        return masked_prob, origin_prob, mask

    def build_mask(self, order):
        num_nodes = len(self.origin_p[0])
        init_index = -1
        false_count = 0
        current_node = order[init_index]
        current_neighbor = self.check_neighbor(current_node)
        mask = [True] * num_nodes
        # situation1: there is no more neighbor in current node.
        if len(current_neighbor) == 0:
            try:
                init_index -= 1
                current_node = order[init_index]
                current_neighbor = self.check_neighbor(current_node)
            except IndexError:
                return None
        for neigh in current_neighbor:
            if neigh not in order:
                mask[neigh] = False
                false_count+=1
        # situation2: all the mask values are True, then we set all possible solutions False
        if false_count == 0:
            mask = [False] * num_nodes
            for node in order:
                mask[node] = True
        mask = torch.BoolTensor(mask)
        # index need to preserve should be False, otherwise, True.
        return mask

    def check_neighbor(self, node):
        out_neigh = list()
        in_neigh = list()
        edge_list = self.origin_p[3]
        e_u = edge_list[0]
        e_v = edge_list[1]
        for i in range(len(e_u)):
            if e_u[i] == node:
                out_neigh.append(e_v[i])
            if e_v[i] == node:
                in_neigh.append(e_u[i])

        return list(set(in_neigh).union(set(out_neigh)))


class actor_critic(nn.Module):
    def __init__(self, args, out_nodes, origin_p, g_x, g_elist, query_input, g_eweight=None):
        super(actor_critic, self).__init__()
        self.out_nodes = out_nodes
        self.origin_p = origin_p
        self.g_x = g_x
        self.g_elist = g_elist
        self.g_eweight = g_eweight
        self.query_feat, self.query_elist = query_input

        share_net = args.share_net
        if share_net:
            self.p_net = self.g_net = GCN(args)
        else:
            # self.p_net = GCN(args)
            self.p_net = GCN(args, True)
            self.g_net = GCN(args)
        self.mlp1 = nn.Sequential(
            nn.Linear(args.out_dim, args.out_dim//2),
            nn.ReLU())
        self.mlp2 = nn.Sequential(
            nn.Linear(args.out_dim, args.out_dim//2),
            nn.ReLU())
        # self.actor = nn.Sequential(
        #     nn.Linear(2 * args.out_dim, args.out_dim),
        #     nn.ReLU(),
        #     nn.Linear(args.out_dim, self.out_nodes),
        #     nn.Softmax()
        # )
        self.actor = nn.Sequential(
            # nn.Linear(3 * args.out_dim, 2 *args.out_dim),
            # nn.ReLU(),
            # nn.Linear(2 * args.out_dim, args.out_dim),
            # nn.ReLU(),
            nn.Linear(args.out_dim, args.out_dim//2),
            nn.ReLU(),
            nn.Linear(args.out_dim//2, 1),
            nn.Softmax(dim=0)
        )
        self.critic = nn.Sequential(
            # nn.Linear(3 * args.out_dim, args.out_dim),
            nn.Linear(args.out_dim, args.out_dim),
            nn.ReLU(),
            nn.Linear(args.out_dim, 1)
        )
        # self.g_feat = self.mlp1(self.g_net(self.g_x, self.g_elist, self.g_eweight))
        # self.g_feat = torch_geometric.nn.global_mean_pool(self.g_feat, torch.tensor([0]*self.g_feat.size(0)))
        # self.query_x = self.mlp2(self.p_net(self.query_feat, self.query_elist))
        self.query_x_all = self.p_net(self.query_feat, self.query_elist)
        # print(self.query_x.size())
        self.query_x = torch_geometric.nn.global_mean_pool(self.query_x_all, torch.tensor([0] * self.query_x_all.size(0)))
        # print(self.query_x.size())

    def forward(self, p_x, p_elist, order, p_eweight=None):
        p_feat_all = self.p_net(p_x, p_elist, p_eweight)
        # g_feat = self.g_net(self.g_x, self.g_elist, self.g_eweight)
        # ####################### we may change the pooling methods.##################################
        p_feat = torch_geometric.nn.global_add_pool(p_feat_all, torch.tensor([0]*p_feat_all.size(0)))   # global info
        # g_feat = torch_geometric.nn.global_mean_pool(g_feat, torch.tensor([0]*g_feat.size(0)))
        # state = torch.cat((p_feat, self.query_x, self.g_feat), dim=1)
        possible_nodes = self.node_selection(order)
        if len(possible_nodes) == 0:
            return None
        for i in range(len(possible_nodes)):
            if i == 0:
                # state = torch.cat((self.query_feat_all[possible_nodes[i]].unsqueeze(0).detach(), p_feat), dim=1)
                state = p_feat_all[possible_nodes[i]].unsqueeze(0).detach()
            else:
                temp_state = p_feat_all[possible_nodes[i]].unsqueeze(0).detach()
                state = torch.cat((state, temp_state), dim=0)
        # state = torch.cat((p_feat, self.query_x), dim=1)
        # print(state)
        value = self.critic(state)
        origin_action = self.actor(state)
        origin_action = torch.transpose(origin_action, 0, 1)

        return value, origin_action, possible_nodes

    def get_critic_value(self, input_state, p_eweight=None):
        p_x, p_elist, order = input_state
        p_feat = self.p_net(p_x, p_elist, p_eweight)
        # g_feat = self.g_net(self.g_x, self.g_elist, self.g_eweight)
        # we may change the pooling methods.
        p_feat = torch_geometric.nn.global_mean_pool(p_feat, torch.tensor([0]*p_feat.size(0)))
        # g_feat = torch_geometric.nn.global_mean_pool(g_feat, torch.tensor([0]*g_feat.size(0)))
        # state_feat = torch.cat((p_feat, self.query_x, self.g_feat), dim=1)
        state_feat = torch.cat((p_feat, self.query_x), dim=1)
        value = self.critic(state_feat)

        return value

    def evaluate_action(self, states, actions):
        for i in range(len(states)):
            p_x, p_elist, order = states[i]
            action = actions[i]
            value, all_action, possible_nodes = self.forward(p_x, p_elist, order)
            true_action = torch.LongTensor([possible_nodes.index(action.item())]).squeeze()
            dist = torch.distributions.Categorical(all_action)
            # we may change the probs, not use the log prob.
            log_prob = dist.log_prob(true_action).view(-1, 1)
            entropy = dist.entropy().mean().view(-1, 1)

            if i == 0:
                values = value
                log_probs = log_prob
                entropies = entropy
            else:
                values = torch.cat((values, value), 0)
                log_probs = torch.cat((log_probs, log_prob), -1)
                entropies = torch.cat((entropies, entropy), -1)

        return values, log_probs, entropies.mean()

    def act(self, p_x, p_elist, order, p_eweight=None):
        value, action, possible_nodes = self.forward(p_x, p_elist, order, p_eweight)
        dist = torch.distributions.Categorical(action)
        choice = dist.sample()
        next_node = possible_nodes[choice.item()]
        # print(choice)

        return next_node, action

    def build_mask(self, order):
        num_nodes = len(self.origin_p[0])
        init_index = -1
        false_count = 0
        current_node = order[init_index]
        # current_neighbor = self.check_neighbor(current_node)
        mask = [True] * num_nodes
        # situation1: there is no more neighbor in current node.
        for idx in reversed(range(len(order))):
            current_node = order[idx]
            current_neighbor = self.check_neighbor(current_node)
            for node in order:
                try:
                    current_neighbor.remove(node)
                except ValueError:
                    continue
            if len(current_neighbor) != 0:
                break
        else:
            return None
        # if len(current_neighbor) == 0:
        #     try:
        #         init_index -= 1
        #         current_node = order[init_index]
        #         current_neighbor = self.check_neighbor(current_node)
        #     except IndexError:
        #         return None
        for neigh in current_neighbor:
            mask[neigh] = False
            false_count+=1
        # situation2: all the mask values are True, then we set all possible solutions False
        # if false_count == 0:
        #     mask = [False] * num_nodes
        #     for node in order:
        #         mask[node] = True
        mask = torch.BoolTensor(mask)
        # index need to preserve should be False, otherwise, True.
        return mask

    def node_selection(self, order):
        for idx in reversed(range(len(order))):
            current_node = order[idx]
            current_neighbor = self.check_neighbor(current_node)
            for node in order:
                try:
                    current_neighbor.remove(node)
                except ValueError:
                    continue
            if len(current_neighbor) != 0:
                break
        else:
            return None
        return current_neighbor

    def update_g_data(self, g_x, g_elist, g_eweight=None):
        self.g_x = g_x
        self.g_elist = g_elist
        self.g_eweight = g_eweight

    def check_neighbor(self, node):
        out_neigh = list()
        in_neigh = list()
        edge_list = self.origin_p[3]
        e_u = edge_list[0]
        e_v = edge_list[1]
        for i in range(len(e_u)):
            if e_u[i] == node:
                out_neigh.append(e_v[i])
            if e_v[i] == node:
                in_neigh.append(e_u[i])

        return list(set(in_neigh).union(set(out_neigh)))

    def update_pattern(self, origin_p, query_input):
        self.origin_p = origin_p
        self.query_feat, self.query_elist = query_input

    def calculate_query_feat(self):
        # self.query_x = self.mlp2(self.p_net(self.query_feat, self.query_elist))
        self.query_x = self.p_net(self.query_feat, self.query_elist)
        self.query_x = torch_geometric.nn.global_mean_pool(self.query_x, torch.tensor([0] * self.query_x.size(0)))

    def update_g_feat(self):
        self.g_feat = self.mlp1(self.g_net(self.g_x, self.g_elist, self.g_eweight))
        self.g_feat = torch_geometric.nn.global_mean_pool(self.g_feat, torch.tensor([0]*self.g_feat.size(0)))


# new update version
class actor_critic_new_update(nn.Module):
    def __init__(self, args, out_nodes, origin_p, g_x, g_elist, query_input, g_eweight=None):
        super(actor_critic_new_update, self).__init__()
        self.out_nodes = out_nodes
        self.origin_p = origin_p
        self.g_x = g_x
        self.g_elist = g_elist
        self.g_eweight = g_eweight
        self.query_feat, self.query_elist = query_input

        share_net = args.share_net
        if share_net:
            self.p_net = self.g_net = GCN(args)
        else:
            # self.p_net = GCN(args)
            self.p_net = GCN(args, True)
            self.g_net = GCN(args)
        self.mlp1 = nn.Sequential(
            nn.Linear(args.out_dim, args.out_dim//2),
            nn.ReLU())
        self.mlp2 = nn.Sequential(
            nn.Linear(args.out_dim, args.out_dim//2),
            nn.ReLU())

        self.actor = nn.Sequential(
            nn.Linear(args.out_dim, args.out_dim//2),
            nn.ReLU(),
            nn.Linear(args.out_dim//2, 1),
            nn.Softmax(dim=0)
        )
        self.critic = nn.Sequential(
            # nn.Linear(3 * args.out_dim, args.out_dim),
            nn.Linear(args.out_dim, args.out_dim),
            nn.ReLU(),
            nn.Linear(args.out_dim, 1)
        )
        # self.g_feat = self.mlp1(self.g_net(self.g_x, self.g_elist, self.g_eweight))
        # self.g_feat = torch_geometric.nn.global_mean_pool(self.g_feat, torch.tensor([0]*self.g_feat.size(0)))
        # self.query_x = self.mlp2(self.p_net(self.query_feat, self.query_elist))
        self.query_x_all = self.p_net(self.query_feat, self.query_elist)
        # print(self.query_x.size())
        self.query_x = torch_geometric.nn.global_mean_pool(self.query_x_all, torch.tensor([0] * self.query_x_all.size(0)))
        # print(self.query_x.size())

    def forward(self, p_x, p_elist, order, p_eweight=None):
        p_feat_all = self.p_net(p_x, p_elist, p_eweight)
        # g_feat = self.g_net(self.g_x, self.g_elist, self.g_eweight)
        # ####################### we may change the pooling methods.##################################
        p_feat = torch_geometric.nn.global_add_pool(p_feat_all, torch.tensor([0]*p_feat_all.size(0)))   # global info
        # g_feat = torch_geometric.nn.global_mean_pool(g_feat, torch.tensor([0]*g_feat.size(0)))
        # state = torch.cat((p_feat, self.query_x, self.g_feat), dim=1)
        possible_nodes = self.node_selection(order)
        if len(possible_nodes) == 0:
            return None
        for i in range(len(possible_nodes)):
            if i == 0:
                # state = torch.cat((self.query_feat_all[possible_nodes[i]].unsqueeze(0).detach(), p_feat), dim=1)
                state = p_feat_all[possible_nodes[i]].unsqueeze(0).detach()
            else:
                temp_state = p_feat_all[possible_nodes[i]].unsqueeze(0).detach()
                state = torch.cat((state, temp_state), dim=0)
        # state = torch.cat((p_feat, self.query_x), dim=1)
        # print(state)
        value = self.critic(state)
        origin_action = self.actor(state)
        origin_action = torch.transpose(origin_action, 0, 1)

        return value, origin_action, possible_nodes

    def get_critic_value(self, input_state, p_eweight=None):
        p_x, p_elist, order = input_state
        p_feat = self.p_net(p_x, p_elist, p_eweight)
        # g_feat = self.g_net(self.g_x, self.g_elist, self.g_eweight)
        # we may change the pooling methods.
        p_feat = torch_geometric.nn.global_mean_pool(p_feat, torch.tensor([0]*p_feat.size(0)))
        # g_feat = torch_geometric.nn.global_mean_pool(g_feat, torch.tensor([0]*g_feat.size(0)))
        # state_feat = torch.cat((p_feat, self.query_x, self.g_feat), dim=1)
        state_feat = torch.cat((p_feat, self.query_x), dim=1)
        value = self.critic(state_feat)

        return value

    def evaluate_action(self, states, actions):
        for i in range(len(states)):
            p_x, p_elist, order = states[i]
            action = actions[i]
            value, all_action, possible_nodes = self.forward(p_x, p_elist, order)
            true_action = torch.LongTensor([possible_nodes.index(action.item())]).squeeze()
            dist = torch.distributions.Categorical(all_action)
            # we may change the probs, not use the log prob.
            log_prob = dist.log_prob(true_action).view(-1, 1)
            entropy = dist.entropy().mean().view(-1, 1)

            if i == 0:
                values = value
                log_probs = log_prob
                entropies = entropy
            else:
                values = torch.cat((values, value), 0)
                log_probs = torch.cat((log_probs, log_prob), -1)
                entropies = torch.cat((entropies, entropy), -1)

        return values, log_probs, entropies.mean()

    def act(self, p_x, p_elist, order, p_eweight=None):
        value, action, possible_nodes = self.forward(p_x, p_elist, order, p_eweight)
        dist = torch.distributions.Categorical(action)
        choice = dist.sample()
        next_node = possible_nodes[choice.item()]
        # print(choice)

        return next_node, action

    def build_mask(self, order):
        num_nodes = len(self.origin_p[0])
        init_index = -1
        false_count = 0
        current_node = order[init_index]
        current_neighbor = self.check_neighbor(current_node)
        mask = [True] * num_nodes
        # situation1: there is no more neighbor in current node.
        for idx in reversed(range(len(order))):
            current_node = order[idx]
            current_neighbor = self.check_neighbor(current_node)
            for node in order:
                try:
                    current_neighbor.remove(node)
                except ValueError:
                    continue
            if len(current_neighbor) != 0:
                break
        else:
            return None
        # if len(current_neighbor) == 0:
        #     try:
        #         init_index -= 1
        #         current_node = order[init_index]
        #         current_neighbor = self.check_neighbor(current_node)
        #     except IndexError:
        #         return None
        for neigh in current_neighbor:
            mask[neigh] = False
            false_count+=1
        # situation2: all the mask values are True, then we set all possible solutions False
        # if false_count == 0:
        #     mask = [False] * num_nodes
        #     for node in order:
        #         mask[node] = True
        mask = torch.BoolTensor(mask)
        # index need to preserve should be False, otherwise, True.
        return mask

    def node_selection(self, order):
        for idx in reversed(range(len(order))):
            current_node = order[idx]
            current_neighbor = self.check_neighbor(current_node)
            for node in order:
                try:
                    current_neighbor.remove(node)
                except ValueError:
                    continue
            if len(current_neighbor) != 0:
                break
        else:
            return None
        return current_neighbor

    def update_g_data(self, g_x, g_elist, g_eweight=None):
        self.g_x = g_x
        self.g_elist = g_elist
        self.g_eweight = g_eweight

    def check_neighbor(self, node):
        out_neigh = list()
        in_neigh = list()
        edge_list = self.origin_p[3]
        e_u = edge_list[0]
        e_v = edge_list[1]
        for i in range(len(e_u)):
            if e_u[i] == node:
                out_neigh.append(e_v[i])
            if e_v[i] == node:
                in_neigh.append(e_u[i])

        return list(set(in_neigh).union(set(out_neigh)))

    def update_pattern(self, origin_p, query_input):
        self.origin_p = origin_p
        self.query_feat, self.query_elist = query_input

    def calculate_query_feat(self):
        # self.query_x = self.mlp2(self.p_net(self.query_feat, self.query_elist))
        self.query_x = self.p_net(self.query_feat, self.query_elist)
        self.query_x = torch_geometric.nn.global_mean_pool(self.query_x, torch.tensor([0] * self.query_x.size(0)))

    def update_g_feat(self):
        self.g_feat = self.mlp1(self.g_net(self.g_x, self.g_elist, self.g_eweight))
        self.g_feat = torch_geometric.nn.global_mean_pool(self.g_feat, torch.tensor([0]*self.g_feat.size(0)))


