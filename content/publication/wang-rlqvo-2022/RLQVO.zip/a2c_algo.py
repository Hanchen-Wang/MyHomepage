import torch
import torch.nn as nn
import torch.optim as optim
import math


class A2cAlgorithm:
    def __init__(self, actor_critic, args):
        self.actor_critic = actor_critic
        self.value_loss_coef = args.value_loss_coef
        self.entropy_coef = args.entropy_coef
        self.lr = args.learning_rate
        self.loss_decay = args.loss_decay

        self.optimizer = optim.RMSprop(actor_critic.parameters(), self.lr)

    def get_true_value(self, states, rewards, dones):
        # the input rewards are the rewards for each step, not the overall rewards.
        true_values = list()
        rewards = torch.FloatTensor(rewards)
        # dones = torch.FloatTensor(dones)

        if dones[-1]:
            next_value = rewards[-1]
        else:
            next_value = self.actor_critic.get_critic_value(states[-1])

        true_values.append(next_value)
        for i in reversed(range(0, len(rewards) - 1)):
            if not dones[i]:
                next_value = rewards[i] + next_value * self.loss_decay
            else:
                next_value = rewards[i]
            true_values.append(next_value)

        true_values.reverse()
        print(true_values)

        return torch.FloatTensor(true_values)

    def update(self, memory):
        states, actions, true_values = memory.pop_all()
        # need to modify the input and evaluate_action
        values, log_probs, entropy = self.actor_critic.evaluate_action(states, actions)
        advantages = true_values - values

        critic_loss = advantages.pow(2).mean()
        # actor_loss = -(log_probs * advantages.detach()).mean()
        # actor_loss = -(log_probs * true_values.detach()).mean()
        actor_loss = -(log_probs * true_values).mean()
        print(actor_loss)
        print(entropy)
        total_loss = self.value_loss_coef * critic_loss + actor_loss - (self.entropy_coef * entropy)
        # total_loss = total_loss.squeeze()
        # print('Total loss is: {}'.format(total_loss))

        self.optimizer.zero_grad()
        total_loss.backward()
        # torch.nn.utils.clip_grad_norm_(self.actor_critic.parameters(), 0.5)
        self.optimizer.step()
        self.actor_critic.update_g_feat()

        return values.mean().item()


class PPO:
    def __init__(self, actor_critic, old_ac, args):
        self.actor_critic = actor_critic
        self.old_ac = old_ac
        self.value_loss_coef = args.value_loss_coef
        self.entropy_coef = args.entropy_coef
        self.lr = args.learning_rate
        self.loss_decay = args.loss_decay
        self.clip_param = 0.2
        self.ppo_epoch = 4

        self.old_ac.load_state_dict(self.actor_critic.state_dict())
        self.optimizer = optim.RMSprop(actor_critic.parameters(), self.lr)

    def get_true_value(self, states, rewards, dones):
        # the input rewards are the rewards for each step, not the overall rewards.
        true_values = list()
        rewards = torch.FloatTensor(rewards)
        # dones = torch.FloatTensor(dones)

        if dones[-1]:
            next_value = rewards[-1]
        else:
            next_value = self.actor_critic.get_critic_value(states[-1])

        true_values.append(next_value)
        for i in reversed(range(0, len(rewards) - 1)):
            if not dones[i]:
                next_value = rewards[i] + next_value * self.loss_decay
            else:
                next_value = rewards[i]
            true_values.append(next_value)

        true_values.reverse()
        # print(true_values)

        return torch.FloatTensor(true_values)

    def update(self, memory):
        states, actions, true_values = memory.pop_all()
        _, old_log_probs, __ = self.old_ac.evaluate_action(states, actions)
        # need to modify the input and evaluate_action

        for _ in range(self.ppo_epoch):
            values, log_probs, entropy = self.actor_critic.evaluate_action(states, actions)
            # advantages = true_values - values
            ratio = torch.exp(log_probs - old_log_probs.detach())
            # critic_loss = advantages.pow(2).mean()
            # actor_loss = -(log_probs * advantages.detach()).mean()
            new_true_values = true_values
            actor_loss_1 = ratio * new_true_values.detach()
            # print(actor_loss_1)
            # need to modify
            actor_loss_2 = torch.clamp(ratio, 1 - self.clip_param,
                                        1 + self.clip_param) * new_true_values.detach()
            # print(actor_loss_2)
            actor_loss = -torch.min(actor_loss_1, actor_loss_2).mean()
            # print(critic_loss)

            # print(entropy)
            total_loss = actor_loss - (self.entropy_coef * entropy)
            # print(total_loss)
            # total_loss = total_loss.squeeze()
            # print('Total loss is: {}'.format(total_loss))

            self.optimizer.zero_grad()
            total_loss.backward()
            # torch.nn.utils.clip_grad_norm_(self.actor_critic.parameters(), 0.5)
            self.optimizer.step()
            self.actor_critic.calculate_query_feat()
            # self.actor_critic.update_g_feat()

        print(actor_loss)
        self.old_ac.load_state_dict(self.actor_critic.state_dict())
        # self.old_ac.update_g_feat()
        self.old_ac.calculate_query_feat()

        return values.mean().item()
