import torch
from copy import deepcopy


class Memory(object):
    def __init__(self):
        self.states, self.actions, self.true_values = list(), list(), list()

    def push(self, state, action, true_value):
        self.states.append(state)
        self.actions.append(action)
        self.true_values.append(true_value)

    def pop_all(self):
        actions = torch.LongTensor(self.actions)
        true_values = torch.FloatTensor(self.true_values).unsqueeze(1)
        states = deepcopy(self.states)

        self.states, self.actions, self.true_values = list(), list(), list()

        return states, actions, true_values
