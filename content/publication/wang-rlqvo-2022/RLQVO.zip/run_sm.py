import torch
import torch.nn as nn
import torch_geometric
import warnings
import argparse
import random
import math
import os
import time
import datetime
import subprocess
from utils import int2onehot, load_data, preprocess_query, \
    preprocess_data_graph, compute_new_feat, vf3,\
    order2str, load_baselines, load_p_data, load_g_graph, Subgraph_Matching, load_first_node, write_result,\
    preprocess_query_graph, preprocess_query_new, compute_new_feat_new, write_time
from model import Agent, actor_critic, actor_critic_new_update
from batch import create_training
from copy import deepcopy
from tqdm import tqdm
from memory import Memory
from a2c_algo import A2cAlgorithm, PPO

warnings.filterwarnings('ignore')
encoding = 'utf-8'
parser = argparse.ArgumentParser()

parser.add_argument('--in_feat', type=int, default=128,
                    help='input feature dim')
parser.add_argument('--out_dim', type=int, default=64,
                    help='dimension of output representation')
parser.add_argument('--hidden_dim', type=int, default=64,
                    help='dimension of hidden feature.')
parser.add_argument('--dropout_ratio', type=float, default=0.2,
                    help='dropout ratio')
parser.add_argument('--learning_rate', type=float, default=0.01,
                    help='learning rate for training')
parser.add_argument('--num_epoch', type=int, default=50,
                    help='number of training epoch')
parser.add_argument('--neg_decay', type=float, default=1.0,
                    help='negative sample loss decay')
parser.add_argument('--share_net', type=bool, default=False,
                    help='whether share parameters between two networks')
parser.add_argument('--pattern_file', type=str, default='rand3.sub.grf',
                    help='the pattern file address')
parser.add_argument('--graph_file', type=str, default='yeast',
                    help='the graph file name')
parser.add_argument('--file_folder', type=str, default='../data/dataset/yeast/grf_data_graph/',
                    help='folder that contains the graph info')
parser.add_argument('--baseline_path', type=str, default='../data/dataset/yeast/',
                    help='folder that contains the baseline file')
parser.add_argument('--query_path', type=str, default='../data/dataset/yeast/grf_query_graph/',
                    help='folder that contains the baseline file')
parser.add_argument('--num_hop', type=int, default=50,
                    help='number of hop of neighbors')
parser.add_argument('--visit_repeat', type=int, default=1,
                    help='number of repeats of vf3 model.')
parser.add_argument('--loss_decay', type=float, default=1.1,
                    help='loss decay with the step of model.')
parser.add_argument('--model_type', type=str, default='PPO',
                    help='choose from A2C and PG (policy gradient)')
parser.add_argument('--value_loss_coef', type=float, default=0.5,
                    help='value loss coefficient.')
parser.add_argument('--entropy_coef', type=float, default=1,
                    help='entropy loss coefficient.')
parser.add_argument('--training_option', type=int, default=1,
                    help='select training option, 0: 4 nodes, 1: 8 nodes,'
                         '2: 16 nodes')
parser.add_argument('--baseline_method', type=str, default='best_DFS',
                    help='The baseline subgraph matching method.')
parser.add_argument('--first_node', type=int, default=0,
                    help='how to select the first node, 0: GQL, 1: max degree')
parser.add_argument('--batch_size', type=int, default=10,
                    help='batch size.')

args = parser.parse_args()
# print(int2onehot(2, 1))
# print(torch.cuda.is_available())

filter_args = 'GQL'
engine_method = 'QSI'
saved_path = './saved_models/' + args.graph_file +'_' + args.model_type +'_' +str(args.training_option) + '_' + str(args.first_node)+'_' + filter_args+'_' + engine_method+ '_' + args.model_type+'_' + time.strftime("%Y-%m-%d %H:%M:%S")+'.pt'
result_path = './results/' + args.graph_file +'_' + args.model_type +'_' +str(args.training_option)+ '_' + str(args.first_node)+'_' + filter_args+'_' + engine_method + '_' + args.model_type+'_' + time.strftime("%Y-%m-%d %H:%M:%S") + '.txt'
time_path = './time_cost/' + args.graph_file +'_' + args.model_type +'_' +str(args.training_option)+ '_' + str(args.first_node)+'_' + filter_args+'_' + engine_method + '_' + args.model_type+'_' + time.strftime("%Y-%m-%d %H:%M:%S") + '.txt'
print(args.graph_file)
torch.autograd.set_detect_anomaly(True)


# used for debug
if __name__ == '__main__':
    order = dict()  # the output list of order of nodes.
    # load data from baseline
    baseline_file_name = args.baseline_path + args.graph_file+ '_' + args.baseline_method+ '_' + 'baseline.txt'
    first_node_file = args.baseline_path + args.graph_file+ '_' + args.baseline_method+ '_first_node.txt'
    baseline_dict = load_baselines(baseline_file_name)
    if args.graph_file == 'yeast':
        if args.training_option == 2:
            secs = 500
        else:
            secs = 500
    elif args.graph_file == 'hprd':
        secs = 45
    elif args.graph_file == 'eu2005':
        secs = 500
    else:
        secs = 300
    if args.first_node == 0:
        first_node_dict = load_first_node(first_node_file)
    graph_file = args.file_folder + args.graph_file +'.grf'
    g_file_sm = graph_file.replace('grf_data_graph', 'data_graph').replace('.grf', '.graph')
    data_graph_info = load_g_graph(graph_file)
    g_feat, g_elist, g_indeg, g_elabel = preprocess_data_graph(data_graph_info)
    train_pattern, test_pattern, train_dict, test_dict = create_training(args.training_option, baseline_dict)
    # query_feat, query_elist, query_indeg, query_elabel = preprocess_data_graph(train_dict[train_pattern[0]])
    query_feat, query_elist, query_indeg, query_elabel = preprocess_query_graph(train_dict[train_pattern[0]], data_graph_info)
    # print(g_feat.size())
    # print(query_feat.size())
    # query_feat = query_feat.unsqueeze(0)
    query_feat = query_feat.type(torch.FloatTensor)
    query_input = [query_feat, query_elist]
    # we use 50% for training.

    if args.training_option == 0:
        num_p_nodes = 4
    elif args.training_option == 1:
        num_p_nodes = 8
    elif args.training_option == 2:
        num_p_nodes = 16
    elif args.training_option == 24:
        num_p_nodes = 24
    elif args.training_option == 32:
        num_p_nodes = 32
    else:
        raise NotImplementedError
    # choose the training model.
    if args.model_type == 'A2C':
        model = actor_critic(args, num_p_nodes, train_dict[train_pattern[0]], g_feat, g_elist, query_input)
        a2c_model = A2cAlgorithm(model, args)
    elif args.model_type == 'PG':
        model = Agent(args, num_p_nodes, train_pattern[0])
    elif args.model_type == 'PPO':
        model = actor_critic(args, num_p_nodes, train_dict[train_pattern[0]], g_feat, g_elist, query_input)
        old_ac = actor_critic(args, num_p_nodes, train_dict[train_pattern[0]], g_feat, g_elist, query_input)
        a2c_model = PPO(model, old_ac, args)
    elif args.model_type == 'PPO_new_update':
        model = actor_critic_new_update(args, num_p_nodes, train_dict[train_pattern[0]], g_feat, g_elist, query_input)
        old_ac = actor_critic_new_update(args, num_p_nodes, train_dict[train_pattern[0]], g_feat, g_elist, query_input)
        a2c_model = PPO(model, old_ac, args)
    else:
        raise NotImplementedError
    # a2c_model = A2cAlgorithm(model, args)
    memory = Memory()

    epoch_num = 0
    processed_tp = list()
    start_info = list()
    for epoch_num in tqdm(range(args.num_epoch)):
        batch_num = 0
        for tp in tqdm(train_pattern):
            if baseline_dict[tp] == 1000000000.0 or baseline_dict[tp] == 0.0:
                print('maybe timeout, skip')
                continue
            states, actions, rewards, dones = list(), list(), list(), list()
            num_hops = len(train_dict[tp][0]) - 1
            ##### add pattern feature to help make decision.########
            query_feat, query_elist, query_indeg, query_elabel = preprocess_query_graph(train_dict[tp], data_graph_info)
            query_feat = query_feat.type(torch.FloatTensor)
            query_input = [query_feat, query_elist]

            if args.model_type == 'PPO':
                model.update_pattern(train_dict[tp], query_input)
                a2c_model.old_ac.update_pattern(train_dict[tp], query_input)
                model.calculate_query_feat()
                a2c_model.old_ac.calculate_query_feat()
            else:
                model.update_pattern(train_dict[tp], query_input)
                model.calculate_query_feat()

            if args.first_node == 0:
                start_node = first_node_dict[tp]
                if start_node == -1:
                    start_node, start_label, p_feat, p_elist = preprocess_query_new(train_dict[tp], data_graph_info)
                else:
                    start_node, start_label, p_feat, p_elist = preprocess_query_new(train_dict[tp], data_graph_info, start_node)
            elif args.first_node == 1:
                start_node, start_label, p_feat, p_elist = preprocess_query_new(train_dict[tp], data_graph_info)
            else:
                raise NotImplementedError
            order[tp] = [start_node]
            curr_state = [p_feat, p_elist, deepcopy(order[tp])]
            for _ in range(num_hops):
                states.append(curr_state)
                if args.model_type == 'PPO':
                    action, origin_action = a2c_model.old_ac.act(curr_state[0], curr_state[1], curr_state[2])
                else:
                    action, origin_action = model.act(curr_state[0], curr_state[1], curr_state[2])
                # print(origin_action)
                actions.append(action)
                # if _ == 0:
                # print(origin_action)
                nnn, max_option = torch.max(origin_action.squeeze(), 0)
                if int(action) == int(max_option):
                    rewards.append(5e-2)  # small positive reward
                else:
                    rewards.append(-0.1)   # large negative reward
                dones.append(False)
                order[tp].append(action)
                p_feat, p_elist = compute_new_feat_new(curr_state[0], curr_state[1], order[tp], train_dict[tp], data_graph_info)
                curr_state = [p_feat, p_elist, deepcopy(order[tp])]

            # print(order[tp])
            # print(origin_action)
            out_order = order2str(order[tp])

            try:
                baseline_return = Subgraph_Matching(tp, g_file_sm, 'ours', order=out_order, filter_method=filter_args, engine=engine_method, timeout_sec=secs)
                baseline_visit = baseline_return.stdout.decode(encoding).split('\n')
                print(baseline_visit)
                if baseline_visit[-1] == 'Aborted':
                    visits_num = -1
                    print('Aborted Error!')
                    continue
                else:
                    for temp_info in baseline_visit:
                        if 'Enumeration number is' in temp_info:
                            visits_num = int(temp_info.split()[-1].replace(':', ''))
                            break
                    else:
                        visits_num = -1
                        print('No enumeration result.')
                        print('###########################')

                        continue
            except subprocess.TimeoutExpired:
                print(tp)
                print('Timeout!')
                visits_num = 1000000000
                continue   # if there is something wrong, skip the training.
            final_state_reward = baseline_dict[tp] - visits_num
            actual_steps = baseline_dict[tp] - visits_num
            # if baseline_dict[tp] > visits_num:
            #     final_state_reward = math.log(baseline_dict[tp] - visits_num)
            # elif baseline_dict[tp] == visits_num:
            #     final_state_reward = 0.0
            # else:
            #     final_state_reward = -math.log(visits_num - baseline_dict[tp])
            # final_state_reward = 10 * actual_steps/baseline_dict[tp]
            if epoch_num % 10 == 0:
                print('Saved search steps on ' + tp +' are: ')
                # print(final_state_reward)
                print(actual_steps)
            rewards[-1] = rewards[-1] + final_state_reward
            dones[-1] = True
            true_values = a2c_model.get_true_value(states, rewards, dones)
            for i in range(len(dones)):
                memory.push(
                    states[i],
                    actions[i],
                    true_values[i]
                )
            a2c_model.update(memory)

    torch.save(model.state_dict(), saved_path)

    ########### for evaluation  ############

    order = dict()  # new initial
    model.eval()
    model.update_g_feat()
    result_list = list()
    time_list = list()
    for tp in test_pattern:
        if baseline_dict[tp] == 1000000000.0:
            print('maybe timeout, skip')
            continue
        states, actions, rewards, dones = list(), list(), list(), list()
        num_hops = len(test_dict[tp][0]) - 1
        query_feat, query_elist, query_indeg, query_elabel = preprocess_query_graph(test_dict[tp], data_graph_info)
        query_feat = query_feat.type(torch.FloatTensor)
        query_input = [query_feat, query_elist]
        model.update_pattern(test_dict[tp], query_input)
        model.calculate_query_feat()
        if args.first_node == 0:
            start_node = first_node_dict[tp]
            if start_node == -1:
                start_node, start_label, p_feat, p_elist = preprocess_query_new(test_dict[tp], data_graph_info)
            else:
                start_node, start_label, p_feat, p_elist = preprocess_query_new(test_dict[tp], data_graph_info, start_node)
        elif args.first_node == 1:
            start_node, start_label, p_feat, p_elist = preprocess_query_new(test_dict[tp], data_graph_info)
        order[tp] = [start_node]
        curr_state = [p_feat, p_elist, deepcopy(order[tp])]
        start_time = time.time()
        for _ in range(num_hops):
            action, origin_action = model.act(curr_state[0], curr_state[1], curr_state[2])
            # nnn, max_option = torch.max(origin_action.squeeze(), 0)
            # if int(action) == int(max_option):
            #     rewards.append(100)
            # else:
            #     rewards.append(-300)
            # dones.append(False)
            order[tp].append(action)
            p_feat, p_elist = compute_new_feat_new(curr_state[0], curr_state[1], order[tp], test_dict[tp], data_graph_info)
            curr_state = [p_feat, p_elist, deepcopy(order[tp])]
        end_time = time.time()
        out_order = order2str(order[tp])
        order_time = end_time - start_time
        # print(order_time)
        # g_file_sm = graph_file.replace('grf_data_graph', 'data_graph').replace('.grf', '.graph')
        try:
            baseline_return = Subgraph_Matching(tp, g_file_sm, 'ours', order=out_order, filter_method=filter_args,
                                                engine=engine_method)
            baseline_visit = baseline_return.stdout.decode(encoding).split('\n')
            # print(baseline_visit)
            if baseline_visit[-1] == 'Aborted':
                visits_num = -1
                print('Aborted Error!')
                continue
            else:
                for temp_info in baseline_visit:
                    if 'Enumeration number is' in temp_info:
                        visits_num = int(temp_info.split()[-1].replace(':', ''))
                    if 'Enumerate time (seconds):' in temp_info:
                        enum_time = float(temp_info.split()[-1])
                        break
                else:
                    visits_num = -1
                    print('No enumeration result.')
                    continue
        except subprocess.TimeoutExpired:
            print(tp)
            print('Timeout!')
            visits_num = 1000000000
            enum_time = 500
            continue  # if there is something wrong, skip the training.

        # baseline_return = Subgraph_Matching(tp, g_file_sm, 'ours', order=out_order, filter_method='CFL', engine='GQL')
        # baseline_visit = baseline_return.readlines()
        # if baseline_visit[-1] == 'Aborted\n':
        #     visits_num = -1
        #     print('Aborted Error!')
        #     continue
        # else:
        #     for temp_info in baseline_visit:
        #         if 'Enumeration number is' in temp_info:
        #             visits_num = int(temp_info.rstrip().split()[-1].replace(':', ''))
        #             break
        #     else:
        #         visits_num = -1
        #         print('No enumeration result.')
        #         continue
        # final_state_reward = math.log(baseline_dict[tp]) - math.log(visits_num)
        # if baseline_dict[tp] >= visits_num:
        #     final_state_reward = math.log(baseline_dict[tp] - visits_num)
        # elif baseline_dict[tp] == visits_num:
        #     final_state_reward = 0.0
        # else:
        #     final_state_reward = -math.log(visits_num - baseline_dict[tp])
        actual_steps = baseline_dict[tp] - visits_num
        total_time = order_time+enum_time
        print('Saved search steps on ' + tp + ' are: ')
        print(actual_steps)
        print(baseline_dict[tp])
        print('order is '+ out_order)
        result_list.append([tp, visits_num, baseline_dict[tp]])
        time_list.append([tp, order_time, enum_time, total_time])
    write_result(result_path, result_list)   # save the results to result path
    write_time(time_path, time_list)   # save the time cost to time path


